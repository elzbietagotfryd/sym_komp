W pliku *.pdf przedstawiono, jak wygląda dokument po skompilowaniu z odwołaniem się do wszystkich zawartych w pliku źródłowym linków. Z uwagi na ilość wykresów, obrazów, etc. użytych w sprawozdaniu, pliki graficzne nie zostały dodane do archiwum, dlatego skompilowane załączonego pliku *.tex nie będzie posiadało tych elementów. 
Podobnie nie zamieszczono pliku bibliografii, gdyż ten został skonstuowany dla całej grupy dokumentów, nie tylko wybranego tutaj. Bibliografia kompilowana jest BibTeXem.  

