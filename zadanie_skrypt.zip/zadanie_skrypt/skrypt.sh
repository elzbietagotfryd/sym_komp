#!/bin/bash

echo "Elzbieta B. Gotfryd"
for f in *.gif; do
	convert $f -normalize `basename $f .gif`.jpg
done

echo "Program do konwersji plikow graficznych"
echo "DONE"
