#!/usr/bin/env python2

from collections import Counter
from random import randint
import pygame, sys
from pygame.locals import *

# globals
wheight = 500
wwidth = 500
cellsize = 5
fps = 1000

test = 0
f = open('logfile.log', 'w')

# check if window in multiples of cells
assert wwidth % cellsize == 0
assert wheight % cellsize == 0

# how many cells in rows and columns
cellwidth = wwidth / cellsize
cellheight = wheight / cellsize

# set up the colours
BLACK =    (0,  0,  0)
WHITE =    (255,255,255)
DARKGRAY = (40, 40, 40)
GREEN =    (0,  255,0)
RED = (255, 0 , 0)

"""
def main():
	pygame.init()
	displaysurf = pygame.display.set_mode((wwidth,wheight))
	pygame.display.set_caption("Hello World!")

	while True:
		for event in pygame.event.get():
			if event.type == QUIT:
				pygame.quit()
				sys.exit()
		pygame.display.update()

if __name__=='__main__':
	main()
	"""
def startingplants():
	plants = Counter()
	for i in range(wwidth/2-wwidth/5,wwidth/2+wwidth/5, cellsize):
		for j in range(wheight/2-wheight/5,wheight/2+wheight/5, cellsize):
			plants[(i,j)] = 20
	return plants

def drawplants(plants):
	for i in plants:
		if plants[i] != 0:
			pygame.draw.rect(displaysurf, GREEN, (i[0], i[1], cellsize, cellsize))
	return None

def startinganimal(count):
	animal = []
	for i in range(count):
		animal.append([randint(0,cellwidth)*cellsize, randint(0,cellheight)*cellsize, 100, 1, 0, 0])
	return animal

def startingcarn(count):
	animal = []
	for i in range(count):
		animal.append([randint(0*cellwidth/3,1*cellwidth/3)*cellsize, randint(0*cellheight/3,1*cellheight/3)*cellsize, 100, 1, 0, 0])
	return animal

def drawanimal(animal, colour):
	for i in animal:
		pygame.draw.rect(displaysurf, colour, (i[0], i[1], cellsize, cellsize))
	return None

def moveanimal(animal):
	for i in animal:
		d = randint(0,7)
		if d in (0,1,2):
			y=1
		elif d in (3,7):
			y=0
		elif d in (4,5,6):
			y=-1
		if d in (2,3,4):
			x=1
		elif d in (1,5):
			x=0
		elif d in (0,6,7):
			x=-1
		i[0]+=x*cellsize
		if i[0]>wwidth:
			i[0] = 0
		elif i[0] < 0:
			i[0] = wwidth-cellsize
		i[1]+=y*cellsize
		if i[1]>wheight:
			i[1] = 0
		elif i[1] < 0:
			i[1] = wheight-cellsize
		i[2]-=1
		i[4]+=1
		i[5]+=1
		if i[2]<=0 or i[4]>=200:
			animal.remove(i)

	return None

def planteat(animal, target):
	for i in animal:
		if (i[0],i[1]) in target and i[2]<150:
			i[2]+=target[(i[0],i[1])]
#			if i[0]  not in range(wwidth/2-wwidth/10,wwidth/2+wwidth/10) and i[1]  not in range(wheight/2-wheight/10,wheight/2+wheight/10):
			del target[(i[0],i[1])]
	return None

def animaleat(animal, target):
	for i in animal:
		for j in target:
			if i[0]==j[0] and i[1]==j[1] and i[2]<150:
				i[2]+=j[2]/2
				target.remove(j)
	return None

def mate(animal, mn, mx):
	for i in animal:
		for j in animal:
			if i[0]==j[0] and i[1]==j[1] and animal.index(i) != animal.index(j) and i[3] == j[3] and i[4]>=10 and j[4]>=10 and i[5]>=10 and j[5]>=10:
				for c in range(randint(mn,mx)):
					animal.append([i[0], i[1], (i[2]+j[2])/3, i[3]+1, 0, 0])
					if c != 0:
						i[5]=j[5]=0
						i[2]-=10
						j[2]-=10
	return None

def growplants(plants, count):
#	for i in plants:
#		plants.update({(i[0],i[1]):10})
	for i in range(count):
		plants.update({(randint(0,cellwidth)*cellsize, randint(0,cellheight)*cellsize):20})
	return None


# main loop
def main():
	test = 0
	pygame.init()
	global displaysurf
	fpsclock = pygame.time.Clock()
	displaysurf = pygame.display.set_mode((wwidth, wheight)) # window size
	pygame.display.set_caption('Game of Evolution v0.1') # window name
	displaysurf.fill(WHITE)

	plants = startingplants()
	growplants(plants, cellwidth*cellheight/1)
	herb = startinganimal(300)
	carn = startinganimal(150)
#	carn = startingcarn(300)

	drawanimal(herb, BLACK)
	drawplants(plants)

	pygame.display.update()
	while True:  # main game loop
		for event in pygame.event.get():
			if event.type == QUIT:
				pygame.quit()
				sys.exit()

		growplants(plants,25)
		moveanimal(herb)
		planteat(herb, plants)
		moveanimal(carn)
		animaleat(carn, herb)
		if len(herb)<1000:
			mate(herb, 0, 3)
		if len(carn)<800:
			mate(carn, 1,3)

		displaysurf.fill(WHITE)
		drawplants(plants)
		drawanimal(herb, BLACK)
		drawanimal(carn, RED)
		pygame.display.update()
		fpsclock.tick(fps)
		print  'day:', test, len(plants), len(herb), len(carn)
		f.write(str(test)+' '+str(len(plants))+' '+str(len(herb))+' '+str(len(carn))+'\n')
		test+=1


if __name__=='__main__':
	main()
	f.close()
