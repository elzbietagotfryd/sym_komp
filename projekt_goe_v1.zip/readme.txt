sposób uruchomienia:

Linux: polecenie z konsoli: python goe.py

Do poprawnego działania wymagany jest pakiet python-pygame.
