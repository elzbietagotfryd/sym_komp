#include <iostream>
#include "funkcje.h"
using namespace std;

void print_hello(){
   cout << "Hello World!!!"
}
