#include <iostream>
#include "funkcje.h"

using namespace std;
int main(){
    print_hello();
    cout << endl;
    cout << "The silnia z 4 to " << silnia(4) << endl;
    return 0;
}
