void print_hello();
int silnia(int n);
